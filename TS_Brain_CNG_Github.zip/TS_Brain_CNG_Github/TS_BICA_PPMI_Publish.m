 clc
close all
clear all
tic
%%

[num, txt, raw]  = xlsread('master_PPMI_BICA_publish.xlsx'); % excel sheet with all subjects Age, Gender, Diagnosis data
txt = txt(2:end,:);
Gender = num(:,4); % Male: 1 & Female : 0
Age = num(:,5);
Diag= num(:,3); % HC: 2 & PD: 1
HCnames = txt(find(Diag == 2),1); % Names of HC 
HC_sl  =  find(Diag==2); % Sl num of HC in the excel as well as SBM matrix
PDnames = txt(find(Diag == 1),1); % Names of PD
PD_sl  =  find(Diag==1); % Sl num of PD in the excel as well as SBM matrix
 Males = find(num(:,4) ==1); % Sl no of males in the entire dataset
Females = find(num(:,4) ==0); % Sl no of females in the entire dataset

load SBM_PPMI_Subject.mat
HC_names =files.name(1:size(HC_sl,1),80:end-6); %80 onwards is the image ID with subject ID
PD_names = files.name(size(HC_sl,1)+1:end,80:end-6); 

for i = 1:length(PD_names)
    inx(i,:) = find(PD_names(i,:) == '.');
    PD_naam = PD_names(i,1:inx(i)-1);
    PDnam{i} = PD_naam;
end
PDnam = PDnam'; % The order of patients in PDnam and PDnames should be same.
clear PD_names
clear PD_naam
%% t test after performing SBM on 386 subjects (168 HC and 218 PD patients together) we got the SBM__group_loading_coeff_.nii in the output directory

grp_load_coeff = icatb_loadData(char('SBM_PPMI__group_loading_coeff_.nii')); % Loading matrix 250*30
load_mat = grp_load_coeff;
for i = 1:size(grp_load_coeff,2)
    % comparing the loading coeff of HC and PD for each of the 30 components
    [h(i) p(i) ci statistics] = ttest2(load_mat(Diag==2,i),load_mat(Diag==1,i));
end
p = p'; 
sig_comp_ttest = find(h==1);

%% Components with significant grp diff  - FDR test
[h_fdr, crit_p_fdr, adj_ci_cvrg, adj_p_fdr]=fdr_bh(p); % h_fdr is a logical binary vector. 
sig_comp_fdr = find(h_fdr==1);  % significant components
[sorted_sig_P, idx_P] = sort(p(sig_comp_fdr)); % Arranging p values in increasing order. Smallest p is more significant. So top 2 significant components are the ones with least  p values.

%% Cohen's d test and top two components
sig_load_mat = load_mat(:,sig_comp_ttest);
for i = 1: size(grp_load_coeff,2)
     mean_HC(i) = mean(load_mat(HC_sl,i),1);  std_HC (i) = std(load_mat(HC_sl,i)); 
    mean_PD(i) = mean(load_mat(PD_sl,i),1);  std_PD (i) = std(load_mat(PD_sl,i));
    numerator(i) = mean_HC(i) - mean_PD(i);
    denominator(i) = sqrt((((numel(HC_sl)-1)*(std_HC(i).^2)) + ((numel(PD_sl)-1)*(std_PD(i).^2)))/(numel(HC_sl)+numel(PD_sl)-2));
    d_Cohen(i) = abs(numerator(i)/denominator(i)); % Cohen's d test is applicable for sample size < 20
end

% Hedges's g test
 Hedges_g = d_Cohen *(1-(3/(4*(numel(HC_sl)+numel(PD_sl))-9))); 
[Hedge_Effect_size, idx_effect] =  sort(Hedges_g, 'descend');
two_sig_comp = load_mat(:,idx_effect(1:2)); % loading coeff of top two sig components

%% N-BiC  Thresholding method from PD subjects only
two_sig_comp_PD = two_sig_comp(PD_sl,:);
mean_of_comp = mean(two_sig_comp_PD,1);
%subgrp 1: from comp 1 only
 if mean_of_comp(1,1) > 0
        idx_1 = find(two_sig_comp_PD(:,1) >= mean_of_comp(1,1) );
else
        idx_1  = find(two_sig_comp_PD(:,1) < mean_of_comp(1,1) );
end
% subgrp2: from comp 2 only
if mean_of_comp(1,2) > 0
        idx_2 = find(two_sig_comp_PD(:,2) >= mean_of_comp(1,2) );
else
        idx_2  = find(two_sig_comp_PD(:,2) < mean_of_comp(1,2) );
end
 %% Subgroup specific subjects from PD subjects only
 Grp_AB_idx = intersect(idx_1, idx_2);        % index common to both A and B
 Grp_AB_names = PDnames(Grp_AB_idx);     % names of subjects common to both A & B
 save Grp_AB_idx.mat  Grp_AB_idx
 save Grp_AB_names.mat  Grp_AB_names
 Grp_A_idx = setdiff(idx_1,Grp_AB_idx);            % exclusively subgroup  A subjects
Grp_A_names = PDnames(Grp_A_idx);
save Grp_A_idx.mat  Grp_A_idx
save Grp_A_names.mat  Grp_A_names

 Grp_B_idx = setdiff(idx_2,Grp_AB_idx);         % exclusively subgroup B subjects
 Grp_B_names = PDnames(Grp_B_idx); 
save Grp_B_idx.mat  Grp_B_idx
save Grp_B_names.mat  Grp_B_names

 %% ANOVA on the loadings of specific subgroups from BICA
PD_loadings = load_mat(PD_sl,:);
j = idx_effect(1:2) % Top five significant components
 group= repelem([{'A'}, {'B'}, {'AB'}], [size(Grp_A_idx,1), size(Grp_B_idx,1), size(Grp_AB_idx,1)]);
 for i = 1:2
    loading_A(:,i) = PD_loadings(Grp_A_idx,j(i));
    loading_B(:,i) = PD_loadings(Grp_B_idx,j(i));
    loading_AB(:,i) = PD_loadings(Grp_AB_idx,j(i));
    A = loading_A(:,i);
    B = loading_B(:,i);
    AB = loading_AB(:,i);
    y_loading =[A' B' AB']; % concatenated loading coefficients of all subgroups
    [p_anova_load,table_load, stats_load] = anova1(y_loading,group);
    Uoff = boxchart(y_loading,'GroupByColor',group) % for coloured box plot
 box on
 if p_anova_load < 0.05
     display('There is a significant difference in loading coefficients between the subgroups')
 else
     display ('NO significant difference in loading coefficients between the subgroups')
 end
    p_anova_loadng(i) = p_anova_load;
 end

toc